package com.bitsinharmony.recognito;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException, UnsupportedAudioFileException {


        File a,b;
        a=new File("5th.wav");
        b=new File("4th.wav");


        AudioInputStream sample = AudioSystem.getAudioInputStream(a);
        AudioFormat format = sample.getFormat();
        Recognito<String> recognito = new Recognito<>(format.getSampleRate());

        VoicePrint print = recognito.createVoicePrint("1", a);
        List<MatchResult<String>> matches = null;
        try {
             matches= recognito.identify(b);
        }catch (Exception e){
            System.out.println("Not Matched !!");
        }

        if(matches!=null){
            MatchResult<String> match = matches.get(0);

            if(match.getKey().equals("1")) {
                System.out.println("Matched!! (" + match.getLikelihoodRatio() + "% positive about it...)");
            }
        }

    }
}
